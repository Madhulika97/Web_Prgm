<?php

$servername="localhost";
$dbusername="root";
$dbpassword="";
$dbname="library";


$conn= new mysqli($servername,$dbusername,$dbpassword,$dbname);

if($conn -> connect_error)
{
	die("Connection failed :".$conn -> connect_error);
}

if(isset($_POST['Submit']))
{
$emp_id=$_POST['ID'];
$emp_name=$_POST['Title'];
$dept=$_POST['Dept'];
$gender=$_POST['gender'];
$DOB=$_POST['date'];
$contact=$_POST['Number'];
$email=$_POST['email'];

$sql = "INSERT INTO add_update_emp VALUES('$emp_id','$emp_name','$dept','$gender','$DOB','$contact','$email')" ;

if($conn->query($sql)==TRUE)
{ 
 echo "Your Info has been entered into Database";
}
else
{
 echo "ERROR" .$sql."<br>" .$conn -> error;
}
}
$conn->close();

?>