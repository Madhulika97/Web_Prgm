<?php

$servername="localhost";
$dbusername="root";
$dbpassword="";
$dbname="library";


$conn= new mysqli($servername,$dbusername,$dbpassword,$dbname);

if($conn -> connect_error)
{
	die("Connection failed :".$conn -> connect_error);
}

if(isset($_POST['Submit']))
{
$emp_id=$_POST['ID'];
$book_title=$_POST['Title'];
$book_id=$_POST['IDD'];
$no_of_copies=$_POST['Number'];
$DOR=$_POST['date'];

$sql = "INSERT INTO return_book VALUES('$emp_id','$book_title','$book_id','$no_of_copies','$DOR')" ;

if($conn->query($sql)==TRUE)
{ 
 echo "Your Info has been entered into Database";
}
else
{
 echo "ERROR" .$sql."<br>" .$conn -> error;
}
}
$conn->close();

?>