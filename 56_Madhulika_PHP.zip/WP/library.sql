-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 23, 2017 at 09:21 AM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

--
-- practice
--
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_book`
--

CREATE TABLE IF NOT EXISTS `add_book` (
  `book_id` varchar(100) NOT NULL,
  `book_title` varchar(100) NOT NULL,
  `book_author` varchar(100) NOT NULL,
  `no_of_copies` varchar(100) NOT NULL,
  `DOP` varchar(100) NOT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `add_book`
--

INSERT INTO `add_book` (`book_id`, `book_title`, `book_author`, `no_of_copies`, `DOP`) VALUES
('12345', 'AP1', 'RD Sharma', '12', '2017-04-11'),
('23', 'asd', 'df', '4', '2017-04-04'),
('454', 'asd', 'asd', '5', '2017-04-18');

-- --------------------------------------------------------

--
-- Table structure for table `add_update_emp`
--

CREATE TABLE IF NOT EXISTS `add_update_emp` (
  `emp_id` varchar(20) CHARACTER SET latin1 NOT NULL,
  `emp_name` text CHARACTER SET latin1 NOT NULL,
  `dept` text CHARACTER SET latin1 NOT NULL,
  `gender` text CHARACTER SET latin1 NOT NULL,
  `DOB` date NOT NULL,
  `contact_no` int(10) NOT NULL,
  `email_id` varchar(200) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `add_update_emp`
--

INSERT INTO `add_update_emp` (`emp_id`, `emp_name`, `dept`, `gender`, `DOB`, `contact_no`, `email_id`) VALUES
('123', 'Aarti', 'Mech', 'Female', '2017-04-19', 2147483647, 'aarti@gmail.com'),
('963', 'ADI', 'IT', 'Male', '2017-04-26', 2147483647, 'adi@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `issue`
--

CREATE TABLE IF NOT EXISTS `issue` (
  `emp_id` varchar(20) NOT NULL,
  `book_title` varchar(20) NOT NULL,
  `book_id` varchar(20) NOT NULL,
  `no_of_copies` varchar(200) NOT NULL,
  `DOI` varchar(200) NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issue`
--

INSERT INTO `issue` (`emp_id`, `book_title`, `book_id`, `no_of_copies`, `DOI`) VALUES
('23', 'asd', '12345', '4', '2017-04-04');

-- --------------------------------------------------------

--
-- Table structure for table `return_book`
--

CREATE TABLE IF NOT EXISTS `return_book` (
  `emp_id` varchar(20) NOT NULL,
  `book_title` varchar(50) NOT NULL,
  `book_id` varchar(20) NOT NULL,
  `no_of_copies` varchar(100) NOT NULL,
  `DOR` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `return_book`
--

INSERT INTO `return_book` (`emp_id`, `book_title`, `book_id`, `no_of_copies`, `DOR`) VALUES
('1233', 'AP1', '45A', '4', '2017-04-11');
