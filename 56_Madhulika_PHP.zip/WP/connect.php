<?php

$servername="localhost";
$dbusername="root";
$dbpassword="";
$dbname="library";


$conn= new mysqli($servername,$dbusername,$dbpassword,$dbname);

if($conn -> connect_error)
{
	die("Connection failed :".$conn -> connect_error);
}

if(isset($_POST['Submit']))
{
$book_id=$_POST['ID'];
$book_title=$_POST['Title'];
$book_author=$_POST['Name'];
$no_of_copies=$_POST['Number'];
$DOP=$_POST['date'];

$sql = "INSERT INTO add_book VALUES('$book_id','$book_title','$book_author','$no_of_copies','$DOP')" ;

if($conn->query($sql)==TRUE)
{ 
 echo "Your Info has been entered into Database";
}
else
{
 echo "ERROR" .$sql."<br>" .$conn -> error;
}
}
$conn->close();

?>